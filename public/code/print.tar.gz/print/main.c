#include <stdio.h>
#include "common.h"

int main(int argc, const char *argv[])
{
    int a = 2, b = 3;
    print(sum(a, b));
    return 0;
}
