#include <stdio.h>

void print(int d)
{
    printf("%d\n", d);
}
