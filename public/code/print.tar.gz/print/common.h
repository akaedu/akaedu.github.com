void print(int);
int sum(int, int);
