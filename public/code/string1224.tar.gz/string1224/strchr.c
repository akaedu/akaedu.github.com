#include <stdio.h>

char *mystrchr(char *s, int c)
{
	while(*s)
	{
		if(*s == c)
			return s;
		s++;
	}

	return NULL;
}

int main(int argc, const char *argv[])
{
	char *s = "hello world";
	char *p;
	p = mystrchr(s, 'l');
	if(p)
		printf("%s\n", p);
	else
		printf("NULL\n");
	return 0;
}
