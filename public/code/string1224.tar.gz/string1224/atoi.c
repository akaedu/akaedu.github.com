#include <stdio.h>

int myatoi(char *s)
{
	int result = 0;

	while(*s)
	{
		if(!isdigit(*s))
			return result;
		result *= 10;
		result += *s - '0';
		s++;
	}

	return result;
}

int main(int argc, const char *argv[])
{
	printf("%d\n", myatoi("1245"));
	return 0;
}
