#include <stdio.h>

void *mymemset(void *s, int c, unsigned int n)
{
	int i;
	char *p = s;
	for(i = 0; i < n; i++)
	{
		p[i] = c;
	}

	return s;
}

int main(int argc, const char *argv[])
{
	char buf[100] = "hello world";
	printf("%s\n", mymemset(buf, 'e', 4));

	return 0;
}
