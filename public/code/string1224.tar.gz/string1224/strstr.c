#include <stdio.h>
#include <string.h>

char *mystrstr(char *heystack, char *needle)
{
	while(*heystack)
	{
		if(strncmp(heystack, needle, strlen(needle)) == 0)
		{
			return heystack;
		}
		heystack++;
	}

	return NULL;
}

int main(int argc, const char *argv[])
{
	char *s = "hello world";
	printf("%s\n", mystrstr(s, "ll"));
	return 0;
}
