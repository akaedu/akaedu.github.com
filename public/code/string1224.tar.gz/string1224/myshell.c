#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{
	int commad_cnt;
	int args_cnt;
	int pip_cnt;
	int in_cnt;
	int out_cnt;
	int pip_args_cnt;
	char *command;
	char *args[10];
	char *pip_args[10];
	char *pip;
	char *in;
	char *out;
}cmd_t;

int parse(char *buf, char *myargv[])
{
	char *p;
	p = buf;
	int i = 0;
	while(myargv[i++] = strtok_r(p, " ", &p));
	return i - 1;
}

int analyse(int myargc, char *myargv[], cmd_t cmd)
{
	char *str[5] = {"cmd", "arg", "pipeto", "out", "in"};
	int stat = 0;
	int flag = 0;
	int pip_flag = 0;
	int i;
	for(i = 0; i < myargc; i++)
	{
		switch(myargv[i][0])
		{
			case '-' : if(stat == 2) stat = 5; else stat = 1;break;
			case '|' : stat = 2; continue; break;
			case '>' : stat = 3; continue; break;
			case '<' : stat = 4; continue; break;
			default: if(flag == 1 && stat == 0) stat = 1; 
				 if(pip_flag == 1 && stat == 2) stat = 5;
				 break;
		}
		switch(stat)
		{
			case 0 : cmd.command = myargv[i]; cmd.commad_cnt++; flag = 1; break;
			case 1 : cmd.args[cmd.args_cnt++] = myargv[i];break;
			case 2 : cmd.pip = myargv[i]; pip_flag = 1; cmd.pip_cnt++;break;
			case 3 : cmd.out = myargv[i]; cmd.out_cnt++; 
				 if(cmd.out_cnt > 1)
				 {
				 	printf("one out permitted!\n");
					return 1;
				 }
				 break;
			case 4 : cmd.in = myargv[i]; cmd.in_cnt++;
				 if(cmd.in_cnt > 1)
				 {
					printf("one in permitted\n");
					return 1;
				 }
				 break;
			case 5 : cmd.pip_args[cmd.pip_args_cnt++] = myargv[i];
				 break;
		}
	}
	if(cmd.commad_cnt)
		printf("cmd:%s\n", cmd.command);
	for(i = 0; i < cmd.args_cnt; i++)
		printf("arg%d:%s\n", i + 1, cmd.args[i]);
	if(cmd.pip_cnt)
		printf("pip_cmd:%s\n", cmd.pip);
	for(i = 0; i < cmd.pip_args_cnt; i++)
		printf("pip_arg%d:%s\n", i + 1, cmd.pip_args[i]);
	if(cmd.in_cnt)
		printf("in:%s\n", cmd.in);
	if(cmd.out_cnt)
		printf("out:%s\n", cmd.out);
}

int main(int argc, const char *argv[])
{
	char buf[100];
	int myargc;
	char *myargv[10];
	cmd_t cmd;
	memset(&cmd, 0, sizeof(cmd));
	while(1)
	{
		printf("myshell$ ");
		gets(buf);
		if(strcmp(buf, "exit") == 0)
			exit(0);
		myargc = parse(buf, myargv);
		if(myargc == 0)
			continue;
		analyse(myargc, myargv, cmd);
	}
	return 0;
}
