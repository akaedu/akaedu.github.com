#include <stdio.h>

int mystrcasecmp(char *s1, char *s2)
{
	while(toupper(*s1) == toupper(*s2))
	{
		if(*s1 == '\0')
			return 0;
		s1++;
		s2++;
	}

	return *s1 - *s2;
}

int main(int argc, const char *argv[])
{
	printf("%d\n", mystrcasecmp("hello", "hell"));
	return 0;
}
