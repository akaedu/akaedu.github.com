#include <stdio.h>

char str[128] = "   ./a.out 100   200   ";
int argc;
char * argv[16];

int i = 0;

int state_trans_table[2][2] =
{
	{ 0, 1 },
	{ 0, 1 }
};

void act_save(void)
{
	argv[argc++] = str + i;
}

void act_end(void)
{
	str[i] = '\0';
}

void parse(void)
{
	int state = 0;
	int input = 0;

	while (str[i])
	{
		if (str[i] == ' ')
			input = 0;
		
		if (str[i] != ' ')
			input = 1;

		if (state == 0 && input == 1)
		{
			state = state_trans_table[state][input];
			act_save();
		}

		if (state == 1 && input == 0)
		{
			state = state_trans_table[state][input];
			act_end();
		}

		i++;
	}

	return;
}

int main(void)
{
	int i = 0;

	parse();

	printf("argc = %d \n", argc);
	for (i = 0; i < argc; i++)
		printf("argv[%d] = %s \n", i, argv[i]);

	return 0;
}
